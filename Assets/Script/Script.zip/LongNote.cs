public class LongNote : Note{
    public int key;
    public float end_beat;
    public float end_second;
    public float end_pos;
    public LongNote(float _beat, float _second, int _face,int _key, float _end_beat, float _end_second):base(_beat, _second, _face)
    {
        key=_key;
        end_beat = _end_beat;
        end_second = 0;
    }
}