using System;

public abstract class Note{
    public float beat;

    public Note(float _beat)
    {
        beat = _beat;
    }
}