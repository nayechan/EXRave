﻿public class LNTouchEvent
{
        
}
