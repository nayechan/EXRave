public class Note{
    public float beat;
    public float second;
    public int face;
    public float pos;
    public UnityEngine.GameObject displayedNote = null;

    public Note(float _beat, float _second, int _face)
    {
        beat = _beat;
        second = _second;
        face = _face;
    }
}