﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class inGamePlay : MonoBehaviour
{
    
    string title, diff;
    AudioSource aus;
    public Text score, time;
    List<BPMData> BPMDataList;
    List<SpeedData> SpeedDataList;
    List<Note> note_list, InitiatedNotes, removeTargets;
    int total_notes = 0, sv_index = 0, note_index = 0;
    public float ready_time = 5.0f;
    bool is_chartready = false, is_started = false;
    float chart_offset = 0.0f, user_offset = 0.0f, total_offset = 0.0f;
    float prev_second = 0.0f, current_position, current_second;
    public float current_speed = 1.0f, user_speed = 180.0f;
    
    public GameObject normalNote, normalNoteD, longNote, slideNote;
    public GameObject[] innerWall;
    public GameObject[] OuterWall;

    Vector3[] BaseVector =
    {
        new Vector3(-2,3.985f,0),
        new Vector3(2,3.985f,0),
        new Vector3(3.985f,2,0),
        new Vector3(3.985f,-2,0),
        new Vector3(2,-3.985f,0),
        new Vector3(-2,-3.985f,0),
        new Vector3(-3.985f,-2,0),
        new Vector3(-3.985f,2,0),

        new Vector3(0,3.985f,0),
        new Vector3(3.985f,0,0),
        new Vector3(0,-3.985f,0),
        new Vector3(-3.985f,0,0)

    };

    Quaternion[] BaseRotation =
    {
        Quaternion.Euler(90,0,0),
        Quaternion.Euler(0,90,90),
        Quaternion.Euler(90,0,0),
        Quaternion.Euler(0,90,90),
    };

    // Start is called before the first frame update
    void Start()
    {
        BPMDataList = new List<BPMData>();
        SpeedDataList = new List<SpeedData>();
        InitiatedNotes = new List<Note>();
        removeTargets = new List<Note>();
        note_list = new List<Note>();

        title = PlayerPrefs.GetString("TargetChart", "error");
        diff = PlayerPrefs.GetString("TargetDiff", "error");
        aus = GetComponent<AudioSource>();

        LoadChart(title, diff);
    }

    float GetSecondByBeat(Bunsu beat)
    {
        float ResultSecond = 0.0f;
        Bunsu timing = new Bunsu(0, 1);
        float cbpm = 120.0f;
        foreach (BPMData data in BPMDataList)
        {
            if (data.timing > beat)
            {
                ResultSecond += (60 / cbpm) * (float)(beat - timing);
                cbpm = data.BPM;
                timing = beat;
                break;
            }
            else
            {
                ResultSecond += (60 / cbpm) * (float)(data.timing - timing);
                cbpm = data.BPM;
                timing = data.timing;
            }
        }

        if (BPMDataList.Count == 0)
        {
            ResultSecond = (float)beat * (60 / cbpm);
        }
        else if(beat > timing)
        {
            ResultSecond += (60 / cbpm) * (float)(beat - timing);
        }
        return ResultSecond;
    }
        
    float GetSecondByBeat(float beat)
    {
        float ResultSecond = 0.0f;
        Bunsu timing = new Bunsu(0, 1);
        float cbpm = 120.0f;
        bool flag = true;
        foreach (BPMData data in BPMDataList)
        {
            if ((float)data.timing > beat)
            {
                ResultSecond += (60 / cbpm) * (beat - (float)timing);
                cbpm = data.BPM;
                flag = false;
                break;
            }
            else
            {
                ResultSecond += (60 / cbpm) * (float)(data.timing - timing);
                cbpm = data.BPM;
                timing = data.timing;
            }
            
            }
        if (beat > (float)timing && flag)
        {
            ResultSecond += (60 / cbpm) * (float)(beat - (float)timing);
        }
        return ResultSecond;
    }

    float GetPositionBySecond(float second)
    {
        float ResultPosition = 0.0f;
        float timing = 0;
        float cspeed = 1;
        foreach (SpeedData data in SpeedDataList)
        {
            if ((float)data.second > second)
            {
                ResultPosition += (cspeed * (second - timing));
                cspeed = data.Speed;
                timing = second;
                break;
            }
            else
            {
                ResultPosition += (cspeed * (data.second - timing));
                cspeed = data.Speed;
                timing = data.second;
            }
        }
        if (second > timing)
        {
            ResultPosition += cspeed * (second - timing);
        }
        return ResultPosition;
    }

    void LoadChart(string name, string diff)
    {
        AudioClip song = Instantiate(Resources.Load<AudioClip>("chart/" + name + "/" + name));
        aus.clip = song;
        TextAsset chartData = Resources.Load<TextAsset>("chart/" + name + "/" + name + "_" + diff);
        string[] chartString = chartData.text.Split('\n');
        if (chartString[0].Trim().Equals("exrave chart file v1"))
        {
            string title = chartString[2].Replace("Title ", " ").Trim();
            string artist = chartString[3].Replace("Artist ", " ").Trim();

            int i = 3;
            while (chartString[i].Trim() != "== BPMData ==") i++;
            string initbpm = chartString[i + 1].Trim().Split(' ')[1];
            string offset = chartString[i + 2].Trim().Split(' ')[1];
            BPMDataList.Add(new BPMData(float.Parse(initbpm),new Bunsu(0,1)));
            SpeedDataList.Add(new SpeedData(1.0f, new Bunsu(0, 1)));
            chart_offset = float.Parse(offset);
            GameObject.Find("songtitle").GetComponent<Text>().text = title;
            while (chartString[i] == "") i++;
            string str;
            while ((str = chartString[i].Trim()) != "== NoteData ==")
            {
                string[] tmp2 = str.Split(' ');
                if (tmp2[0] == "Speed")
                {
                    string speed = tmp2[1];
                    string[] timing = tmp2[2].Split('/');
                    Bunsu timingData = new Bunsu(int.Parse(timing[0]), int.Parse(timing[1]));
                    float speedv = float.Parse(speed);
                    SpeedData speedData = new SpeedData(speedv, timingData);
                    SpeedDataList.Add(speedData);

                }
                else if (tmp2[0] == "BPM")
                {
                    string bpm = tmp2[1];
                    string[] timing = tmp2[2].Split('/');
                    Bunsu timingData = new Bunsu(int.Parse(timing[0]), int.Parse(timing[1]));
                    float bpmv = float.Parse(bpm);
                    BPMData bpmData = new BPMData(bpmv, timingData);
                    BPMDataList.Add(bpmData);
                }
                i++;

            }
            while ((str = chartString[i].Trim()) != "")
            {
                string[] tmp2 = str.Split(' ');
                if (tmp2[0] == "NormalNote")
                {
                    string beat = tmp2[1];
                    string face = tmp2[2];
                    string key = tmp2[3];

                    beat = beat.Replace("beat:", "");
                    face = face.Replace("face:", "");
                    key = key.Replace("key:", "");

                    float beatv = float.Parse(beat);
                    int facev = int.Parse(face);
                    int keyv = int.Parse(key);

                    NormalNote normalNote = new NormalNote(beatv, 0, facev, keyv);
                    note_list.Add(normalNote);

                }
                else if (tmp2[0] == "LongNote")
                {
                    string beat = tmp2[1];
                    string face = tmp2[2];
                    string key = tmp2[3];
                    string end = tmp2[4];

                    beat = beat.Replace("beat:", "");
                    face = face.Replace("face:", "");
                    key = key.Replace("key:", "");
                    end = end.Replace("end:", "");

                    float beatv = float.Parse(beat);
                    int facev = int.Parse(face);
                    int keyv = int.Parse(key);
                    float endv = float.Parse(end);
                    LongNote longNote = new LongNote(beatv, 0, facev, keyv, endv, 0/**/);
                    note_list.Add(longNote);

                }
                else if (tmp2[0] == "SlideNote")
                {
                    string beat = tmp2[1];
                    string face = tmp2[2];
                    string pos = tmp2[3];

                    beat = beat.Replace("beat:", "");
                    face = face.Replace("face:", "");
                    pos = pos.Replace("pos:", "");

                    float beatv = float.Parse(beat);
                    int facev = int.Parse(face);
                    float posv = float.Parse(pos);
                    SlideNote slideNote = new SlideNote(beatv, 0, facev, posv);
                    note_list.Add(slideNote);
                }

                i++;
            }

            BPMDataList.Sort(delegate(BPMData a, BPMData b)
            {
                if (a.timing > b.timing) return 1;
                else if (a.timing < b.timing) return -1;
                else return 0;
            });

            foreach(SpeedData speedData in SpeedDataList)
            {
                speedData.second = GetSecondByBeat(speedData.timing);
            }
            SpeedDataList.Sort(delegate (SpeedData a, SpeedData b)
            {
                if (a.second > b.second) return 1;
                else if (a.second < b.second) return -1;
                else return 0;
            });
            foreach (Note note in note_list)
            {
                note.second = GetSecondByBeat(note.beat);

                if (note.GetType() == typeof(LongNote))
                {
                    ((LongNote)note).end_second = GetSecondByBeat(((LongNote)note).end_beat);
                }

                note.pos = GetPositionBySecond(note.second);

                if(note.GetType() == typeof(LongNote))
                {
                    ((LongNote)note).end_pos = GetPositionBySecond(((LongNote)note).end_second);
                }
                
            }
            note_list.Sort(delegate (Note a, Note b)
            {
                if (a.second > b.second) return 1;
                else if (a.second < b.second) return -1;
                else return 0;
            });
            string str1 = "";
            foreach (Note n in note_list)
            {
                str1 += (n.pos + " ");
            }
            Debug.Log(str1);



            total_offset = chart_offset + user_offset;
            current_position = total_offset;

            total_notes = note_list.Count;

            current_second = total_offset-ready_time;
            current_position = total_offset - ready_time;

            is_chartready = true;
        }
    }

    void NoteMovement()
    {
        while (note_index < note_list.Count && note_list[note_index].pos - (300 / user_speed) <= current_position - total_offset)
        {
            if (note_list[note_index].GetType() == typeof(NormalNote))
            {
                NormalNote nn = (NormalNote)note_list[note_index];
                Vector3 v = BaseVector[(nn.face - 1) * 2 + nn.key - 1];
                Quaternion q = BaseRotation[nn.face - 1];
                v.z = (note_list[note_index].pos - current_position) * user_speed;
                GameObject g = GameObject.Instantiate(normalNote, v, q);
                g.name = "normalNote";
                note_list[note_index].displayedNote = g;
                InitiatedNotes.Add(note_list[note_index]);
            }
            else if (note_list[note_index].GetType() == typeof(LongNote))
            {
                LongNote ln = (LongNote)note_list[note_index];
                float sp = ln.pos;
                float ep = ln.end_pos;

                Vector3 v = BaseVector[(ln.face - 1) * 2 + ln.key - 1];
                Quaternion q = BaseRotation[ln.face - 1];
                v.z = (sp - current_position) * user_speed;
                GameObject g = GameObject.Instantiate(longNote, v, q);
                g.name = "longNote";
                g.GetComponent<SpriteRenderer>().size = new Vector2(3.84f, (ep - sp) * user_speed);
                ln.displayedNote = g;
                InitiatedNotes.Add(ln);
            }
            else if (note_list[note_index].GetType() == typeof(SlideNote))
            {
                SlideNote sn = (SlideNote)note_list[note_index];
                Vector3 v = BaseVector[sn.face + 7];
                if (sn.face % 2 == 1)
                {
                    v.x = sn.x_pos;
                }
                else
                {
                    v.y = sn.x_pos;
                }
                Quaternion q = BaseRotation[sn.face - 1];
                v.z = (note_list[note_index].pos - current_position) * user_speed;
                GameObject g = GameObject.Instantiate(slideNote, v, q);
                g.name = "slideNote";
                note_list[note_index].displayedNote = g;
                InitiatedNotes.Add(note_list[note_index]);
            }


            note_index++;
        }

        foreach (Note n in InitiatedNotes)
        {
            if (n.GetType() == typeof(NormalNote))
            {
                GameObject g = n.displayedNote;
                float vx = g.transform.position.x;
                float vy = g.transform.position.y;
                float vz = (n.pos - current_position) * user_speed;
                Vector3 v = new Vector3(vx, vy, vz);
                g.transform.position = v;
                if (n.pos + 1 < current_position) removeTargets.Add(n);
            }
            else if (n.GetType() == typeof(LongNote))
            {
                GameObject g = n.displayedNote;
                float vx = g.transform.position.x;
                float vy = g.transform.position.y;
                float vz = (n.pos - current_position) * user_speed;
                Vector3 v = new Vector3(vx, vy, vz);
                g.transform.position = v;
                if (n.pos + 1 < current_position) removeTargets.Add(n);
            }
            else if (n.GetType() == typeof(SlideNote))
            {
                GameObject g = n.displayedNote;
                float vx = g.transform.position.x;
                float vy = g.transform.position.y;
                float vz = (n.pos - current_position) * user_speed;
                Vector3 v = new Vector3(vx, vy, vz);
                g.transform.position = v;
                if (n.pos + 1 < current_position) removeTargets.Add(n);
            }
        }

        foreach (Note n in InitiatedNotes)
        {
            GameObject g = n.displayedNote;
            float vx = g.transform.position.x;
            float vy = g.transform.position.y;
            float vz = (n.pos - current_position) * user_speed;
            Vector3 v = new Vector3(vx, vy, vz);
            g.transform.position = v;
        }

        foreach (Note n in removeTargets)
        {
            InitiatedNotes.Remove(n);
            Destroy(n.displayedNote);
        }

        removeTargets.Clear();
    }

    void Judgement()
    {
        foreach(Touch touch in Input.touches)
        {
            if(touch.phase == TouchPhase.Began)
            {
                Ray ray = Camera.main.ScreenPointToRay(touch.position);
                RaycastHit hit;
                if (Physics.Raycast(ray, out hit))
                {
                     
                }
            }
            if (touch.phase == TouchPhase.Stationary || touch.phase == TouchPhase.Moved)
            {
                Ray ray = Camera.main.ScreenPointToRay(touch.position);
                RaycastHit hit;
                if (Physics.Raycast(ray, out hit))
                {
                    
                }
            }
            if(touch.phase == TouchPhase.Canceled || touch.phase == TouchPhase.Ended)
            {
                Ray ray = Camera.main.ScreenPointToRay(touch.position);
                RaycastHit hit;
                if (Physics.Raycast(ray, out hit))
                {
                    
                }
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (!GetComponent<GamePause>().PauseUI.activeSelf && is_chartready)
        {
            if (ready_time > 0)
            {
                ready_time -= Time.deltaTime;
                current_second += Time.deltaTime;
                current_position += Time.deltaTime;
                if (current_second > 0) current_second = 0;
                if (current_position > 0) current_position = 0;
            }
            else
            {
                if (!is_started)
                {
                    aus.Play();
                    is_started = true;
                }
                else
                {
                    current_second += Time.deltaTime;
                    current_position += Time.deltaTime * current_speed;
                }
            }

        }
        
        if(SpeedDataList.Count > 0)
        {
            if (SpeedDataList[0].second <= current_second)
            {
                current_speed = SpeedDataList[0].Speed;
                SpeedDataList.RemoveAt(0);
            }
        }

        NoteMovement();
        Judgement();


        prev_second = current_second;
    }
}
