public class SlideNote : Note{
    public float x_pos;
    public SlideNote(float _beat, float _second, int _face,float _x_pos):base(_beat, _second,  _face)
    {
        x_pos = _x_pos;
    }
}