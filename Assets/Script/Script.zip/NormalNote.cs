public class NormalNote : Note{
    public int key;
    public NormalNote(float _beat, float _second, int _face,int _key):base(_beat, _second, _face)
    {
        key=_key;
    }
}